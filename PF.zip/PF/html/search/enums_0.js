var searchData=
[
  ['atencion_0',['Atencion',['../main2_8cpp.html#a78d260dc06bfa90e7eb603e21acc6d56',1,'main2.cpp']]]
];
