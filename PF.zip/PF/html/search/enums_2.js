var searchData=
[
  ['opciones_0',['Opciones',['../main2_8cpp.html#a51895b572f6326a7f2db364ea2fa886f',1,'main2.cpp']]]
];
