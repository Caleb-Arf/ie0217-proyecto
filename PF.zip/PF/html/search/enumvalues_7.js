var searchData=
[
  ['salir_0',['SALIR',['../main2_8cpp.html#a51895b572f6326a7f2db364ea2fa886fadce475126bc4e905e1c004dba34ab38e',1,'main2.cpp']]],
  ['solicitarp_1',['SOLICITARP',['../main2_8cpp.html#a78d260dc06bfa90e7eb603e21acc6d56ad681b7d5d0761e60b0835e3a1a40c7e0',1,'main2.cpp']]]
];
