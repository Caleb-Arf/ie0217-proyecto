var searchData=
[
  ['redimircdp_0',['REDIMIRCDP',['../main2_8cpp.html#a78d260dc06bfa90e7eb603e21acc6d56a9e155ac637eceaa6771400f3e11c2f63',1,'main2.cpp']]],
  ['regresar_1',['REGRESAR',['../main2_8cpp.html#a78d260dc06bfa90e7eb603e21acc6d56ae5609925b041e0727cfd7ccf70f1d7c0',1,'main2.cpp']]],
  ['regresar2_2',['REGRESAR2',['../main2_8cpp.html#ab1764b91c3b44a5988564bbfe1d6e352a028ff0147c933348b06231a59f0ca66c',1,'main2.cpp']]]
];
