var searchData=
[
  ['obtener_0',['OBTENER',['../main2_8cpp.html#a78d260dc06bfa90e7eb603e21acc6d56ad0b6ae5b1d9223790a388f60cab039bd',1,'main2.cpp']]]
];
