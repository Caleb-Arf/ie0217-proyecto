var indexSectionsWithContent =
{
  0: "acdegimoprstv",
  1: "co",
  2: "cemort",
  3: "acdegimoprstv",
  4: "aio",
  5: "acdeiorst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums",
  5: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Enumerations",
  5: "Enumerator"
};

