var searchData=
[
  ['estado_0',['ESTADO',['../main2_8cpp.html#a78d260dc06bfa90e7eb603e21acc6d56aa566af333a7d685ef9cfd327295ab2a7',1,'main2.cpp']]]
];
