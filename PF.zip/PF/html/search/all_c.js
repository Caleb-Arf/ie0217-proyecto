var searchData=
[
  ['validarcorreo_0',['validarCorreo',['../clientes_8hpp.html#a046219743f25040c96360482a6a58236',1,'clientes.hpp']]],
  ['validardireccion_1',['validarDireccion',['../clientes_8hpp.html#a62c888a1e1c62df66873a0eb36b07cc3',1,'clientes.hpp']]],
  ['validarnombre_2',['validarNombre',['../clientes_8hpp.html#a7ecd26a48cebf8e04ff486064ec83be6',1,'clientes.hpp']]],
  ['validartelefono_3',['validarTelefono',['../clientes_8hpp.html#ad97247aab3ced5dca8dbbcd52f5b74d9',1,'clientes.hpp']]],
  ['validartipocuenta_4',['validarTipoCuenta',['../clientes_8hpp.html#a76b333600bae8b51db95f12908908b13',1,'clientes.hpp']]]
];
